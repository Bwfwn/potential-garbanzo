using UnityEngine;
public interface IInputComponent
{
    Vector3 GetMovementDirection(Vector3 currentPosition);
}


