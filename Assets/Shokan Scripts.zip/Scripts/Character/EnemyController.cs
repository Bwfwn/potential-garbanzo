using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
    public Character targetCharacter; 

    private EnemyCharacter[] enemies; 

    private void Start()
    {
        enemies = GetComponentsInChildren<EnemyCharacter>();
    }

    private void Update()
    {
        foreach (var enemy in enemies)
        {
            enemy.TargetCharacter = targetCharacter;
            enemy.Update();
        }
    }

}
