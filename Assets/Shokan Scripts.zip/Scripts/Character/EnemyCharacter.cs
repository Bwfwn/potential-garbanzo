using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyCharacter : Character
{
    [SerializeField] private AIState currentState;
    [SerializeField] private Character targetCharacter;

    public Character TargetCharacter 
    {
        get => targetCharacter;
        set => targetCharacter = value;
    }

    private float timeBetweenAttackCounter = 0;
    private float attackDistance = 3f;      

    public override void Start()
    {
        base.Start();
        LiveComponent = new ImmortalLiveComponent();
        DamageComponent = new CharacterDamageComponent(this);
    }

    public override void Update()
    {
        float distanceToTarget = Vector3.Distance(targetCharacter.transform.position, transform.position);

        switch (currentState)
        {
            case AIState.None:
                break;

            case AIState.MoveToTarget:
                if (distanceToTarget <= attackDistance)
                {
                    currentState = AIState.Attack;
                }
                else
                {
                    MoveTowardsTarget();
                }
                break;

            case AIState.Attack:
                if (distanceToTarget > attackDistance)
                {
                    currentState = AIState.MoveToTarget;
                }
                else
                {
                    PerformAttack();
                }
                break;
        }

        if (timeBetweenAttackCounter > 0)
            timeBetweenAttackCounter -= Time.deltaTime;
    }

    private void MoveTowardsTarget()
    {
        Vector3 direction = targetCharacter.transform.position - transform.position;
        direction.Normalize();

        MovableComponent.Move(direction);
        MovableComponent.Rotation(direction);
    }

    private void PerformAttack()
    {
        if (timeBetweenAttackCounter <= 0)
        {
            DamageComponent.MakeDamage(targetCharacter);
            timeBetweenAttackCounter = characterData.TimeBetweenAttacks;
        }
    }
}
