using UnityEngine;

public class AIInputComponent : IInputComponent
{
    private Character targetCharacter;

    public AIInputComponent(Character target)
    {
        targetCharacter = target;
    }

    public Vector3 GetMovementDirection(Vector3 currentPosition)
    {
        Vector3 direction = targetCharacter.transform.position - currentPosition;
        return direction.normalized;
    }
}
